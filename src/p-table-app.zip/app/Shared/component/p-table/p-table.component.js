"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const core_1 = require("@angular/core");
const p_table_pagger_1 = require("./p-table-pagger");
let PTableComponent = class PTableComponent {
    constructor(pagerService, differs, renderer) {
        this.pagerService = pagerService;
        this.differs = differs;
        this.renderer = renderer;
        this.checkboxCallbackFn = new core_1.EventEmitter() || null;
        this.callbackFnOnPageChange = new core_1.EventEmitter() || null;
        this.radioButtonCallbackFn = new core_1.EventEmitter() || null;
        this.cellClickCallbackFn = new core_1.EventEmitter() || null;
        this.customReflowFn = new core_1.EventEmitter() || null;
        this.editUpdateColumn = true;
        this.noRecord = true;
        this.pTableData = [{}];
        this.pTableDatalength = 0;
        this.startPageNo = 0;
        this.totalColspan = 0;
        this.pageNo = 0;
        this.rowLimitArray = [10, 20, 50, 100, 200, 500, 1000];
        this.enabledPagination = true;
        this.globalSearchValue = "";
        this.customFilterUniqueArray = [];
        this.columnWiseMasterData = [];
        this.filterItemsCheckedAll = false;
        this.popupFilterColor = 'black';
        this.storedFilteredInfo = [];
        this.columnSearchValue = "";
        this.activeReflow = false;
        this.customReflowActive = false;
        this.pTableColumnSearch = "";
        this.pTableColumnCustomizationList = [];
        this.pTableColumnReorder = [];
        this.settingsTabs = [{ tab: "columnShowHide", tabName: "Show/Hide", active: true }];
        this.pModalSetting = {
            modalTitle: "",
            modalSaveBtnCaption: "Save"
        };
        this.pager = {};
        this.activeTabName = "columnShowHide";
        this.tempStyle = [];
        this.differ = differs.find({}).create(null);
    }
    ngOnInit() {
        if (this.pTableSetting == null) {
            return false;
        }
        if (this.pTableSetting["enabledSerialNo"]) {
            this.totalColspan = this.totalColspan + 1;
        }
        if (this.pTableSetting["enabledCheckbox"]) {
            this.totalColspan = this.totalColspan + 1;
        }
        if (this.pTableSetting["enabledEditBtn"]) {
            this.totalColspan = this.totalColspan + 1;
        }
        if (this.pTableSetting["enabledRadioBtn"]) {
            this.totalColspan = this.totalColspan + 1;
        }
        if (this.pTableSetting["enabledReordering"]) {
            this.settingsTabs.push({ tab: "columnOrder", tabName: "Reorder", active: false });
        }
        this.pTableSetting["radioBtnColumnHeader"] = this.pTableSetting["radioBtnColumnHeader"] || 'Select';
        this.pTableSetting["checkboxColumnHeader"] = this.pTableSetting["checkboxColumnHeader"] || 'Select';
        this.totalColspan = this.totalColspan + this.pTableSetting["tableColDef"].length;
        this.maximumPaggingDisplay = this.pTableSetting["displayPaggingSize"] || 10;
        if (!this.pTableSetting["enabledPagination"] && this.pTableSetting["enabledPagination"] != undefined) {
            this.enabledPagination = false;
            this.pageSize = 10000;
        }
        else {
            this.pageSize = this.pTableSetting["pageSize"] || 10;
        }
        //for advanced column filter 
        this.storedFilteredInfo = [];
        this.columnSearchValue = "";
        this.globalSearchValue = "";
        console.log("call ng init..");
        jQuery("#" + this.pTableSetting["tableID"] + " .column-filter-active").css('color', 'white');
        this.pTableColumnCustomizationList = JSON.parse(JSON.stringify(this.pTableSetting.tableColDef)) || [];
        this.pTableColumnReorder = JSON.parse(JSON.stringify(this.pTableSetting.tableColDef)) || [];
    }
    ngDoCheck() {
        if (this.pTableSetting == null) {
            return false;
        }
        var changes = this.differ.diff(this.pTableMasterData);
        if (changes) {
            this.pTableData = this.pTableMasterData || [];
            this.pTableDatalength = this.pTableData.length || 0;
            if (this.pTableSetting.disabledTableReset) {
                this.fnShowPreviousFilteredState();
            }
            else {
                this.storedFilteredInfo = [];
                this.columnSearchValue = "";
                this.globalSearchValue = "";
                jQuery("#" + this.pTableSetting["tableID"] + " .column-filter-active").css('color', 'white');
            }
            //set page state
            if (this.pTableSetting.enabledStaySelectedPage && this.pageNo > 0) {
                this.setPage(this.pageNo);
            }
            else {
                this.setPage(1);
            }
        }
    }
    fnClickPTableCell(event, isCellClick = false, currentCellName, activeClickForThisCell, data) {
        if (isCellClick && (activeClickForThisCell == "Yes" || activeClickForThisCell == "true")) {
            this.cellClickCallbackFn.emit({ cellName: currentCellName, record: data, event: event });
        }
        else {
            return;
        }
    }
    fnSaveModalInfo() {
        // this.fnActionOnSaveBtn.emit(this.modalSaveFnParam);
    }
    fnEditRecord(record) {
        jQuery("#customModal").modal("show");
    }
    fnDeleteRecord(record) {
    }
    fnFilterPTable(args, executionType = false) {
        return __awaiter(this, void 0, void 0, function* () {
            let execution = false;
            args = args.trim();
            //this.pTableData=JSON.parse( JSON.stringify( this.pTableMasterData))||[];    
            if (args && this.pTableMasterData.length > 0) {
                let filterKeys = Object.keys(this.pTableMasterData[0]);
                this.pTableData = yield this.pTableMasterData.filter((item, index, array) => {
                    let returnVal = false;
                    for (let i = 0; i < this.pTableSetting["tableColDef"].length; i++) {
                        if (typeof item[this.pTableSetting["tableColDef"][i]["internalName"]] == "string") {
                            if (item[this.pTableSetting["tableColDef"][i]["internalName"]].toLowerCase().includes(args.toLowerCase())) {
                                returnVal = true;
                            }
                        }
                        else if (typeof item[this.pTableSetting["tableColDef"][i]["internalName"]] == "number") {
                            if (item[this.pTableSetting["tableColDef"][i]["internalName"]].toString().indexOf(args.toString()) > -1) {
                                returnVal = true;
                            }
                        }
                        else {
                        }
                    }
                    return returnVal;
                });
            }
            else {
                this.pTableData = this.pTableMasterData;
            }
            if (executionType) {
            }
            else {
                this.storedFilteredInfo = [];
                jQuery("#" + this.pTableSetting["tableID"] + " .column-filter-active").css('color', 'white');
                this.setPage(1);
            }
        });
    }
    setPage(page) {
        this.pageNo = page;
        this.pager = this.pagerService.getPager(this.pTableData.length, page, this.pageSize, this.maximumPaggingDisplay);
        if (page < 1 || page > this.pager.totalPages) {
            if (page - 1 <= this.pager.totalPages && this.pager.totalPages != 0) {
                if (page <= 0) {
                    this.setPage(1);
                }
                else {
                    this.setPage(page - 1);
                }
                return;
            }
        }
        //this.pager = this.pagerService.getPager(this.pTableData.length, page, this.pageSize, this.maximumPaggingDisplay);
        if (this.pTableData.length == 0) {
            this.pagedItems = [];
        }
        else {
            this.pagedItems = this.pTableData.slice(this.pager.startIndex, this.pager.endIndex + 1);
        }
        this.pTableDatalength = this.pTableData.length;
        //showing page number
        this.startPageNo = (this.pager.currentPage - 1) * this.pager.pageSize + 1;
        let endPageNo = 0;
        if (this.pTableData.length == 0) {
            this.startPageNo = 0;
        }
        if ((this.pager.currentPage) * this.pager.pageSize < this.pTableData.length) {
            endPageNo = (this.pager.currentPage) * this.pager.pageSize;
        }
        else {
            endPageNo = this.pTableData.length;
        }
        if (this.pTableData.length == this.pTableMasterData.length) {
            this.showingPageDetails = 'Showing ' + this.startPageNo + ' to ' + endPageNo + ' of ' + this.pTableData.length + ' records';
        }
        else {
            this.showingPageDetails = 'Showing ' + this.startPageNo + ' to ' + endPageNo + ' of ' + this.pTableData.length + ' records (filtered from ' + this.pTableMasterData.length + ' total records)';
        }
        //to remove checkbox 
        if (this.pTableSetting["enabledCheckbox"]) {
            jQuery("#" + this.pTableSetting["tableID"] + " th input.p-table-select-all").prop("checked", false);
            jQuery("#" + this.pTableSetting["tableID"] + " td input.checkbox-" + this.pTableSetting["tableID"]).prop("checked", false);
        }
        //call the function after the page changes
        this.callbackFnOnPageChange.emit({ pageNo: page });
    }
    fnColumnSorting(colName, pTableID, isSorting = true) {
        if (!isSorting) {
            return;
        }
        if (jQuery("#" + pTableID + " thead th." + colName).hasClass("sorting")) {
            jQuery("#" + pTableID + " thead th.sorting-active").addClass("sorting").removeClass("sorting-down").removeClass("sorting-up");
            jQuery("#" + pTableID + " thead th." + colName).addClass("sorting-up").removeClass("sorting");
            this.pTableData = this.pTableData.sort((n1, n2) => {
                if (n1[colName] > n2[colName]) {
                    return 1;
                }
                if (n1[colName] < n2[colName]) {
                    return -1;
                }
                return 0;
            });
        }
        else if (jQuery("#" + pTableID + " thead th." + colName).hasClass("sorting-up")) {
            jQuery("#" + pTableID + " thead th." + colName).addClass("sorting-down").removeClass("sorting-up");
            this.pTableData = this.pTableData.sort((n1, n2) => {
                if (n1[colName] < n2[colName]) {
                    return 1;
                }
                if (n1[colName] > n2[colName]) {
                    return -1;
                }
                return 0;
            });
        }
        else if (jQuery("#" + pTableID + " thead th." + colName).hasClass("sorting-down")) {
            jQuery("#" + pTableID + " thead th." + colName).addClass("sorting-up").removeClass("sorting-down");
            this.pTableData = this.pTableData.sort((n1, n2) => {
                if (n1[colName] > n2[colName]) {
                    return 1;
                }
                if (n1[colName] < n2[colName]) {
                    return -1;
                }
                return 0;
            });
        }
        this.setPage(1);
    }
    fnOperationOnCheckBox(event, args) {
        if (event.target.checked) {
            jQuery(".checkbox-" + args).prop("checked", true);
        }
        else {
            jQuery(".checkbox-" + args).prop("checked", false);
        }
        this.checkboxCallbackFn.emit({ checkedStatus: event.target.checked, record: "", type: "all-select" });
    }
    fnIndividualCheckboxAction(e, recordInfo) {
        this.checkboxCallbackFn.emit({ checkedStatus: e.target.checked, record: recordInfo, type: "individual" });
    }
    fnIndividualRadioAction(e, recordInfo) {
        this.radioButtonCallbackFn.emit({ checkedStatus: e.target.checked, record: recordInfo, type: "individual" });
    }
    fnChangePTableRowLength(records) {
        this.pageSize = records;
        this.setPage(1);
    }
    fnChangePTableDataLength(event) {
        let records = event.target.value;
        this.pageSize = records;
        this.setPage(1);
    }
    fnResizeColumn(event) {
        this.start = event.target;
        this.pressed = true;
        this.startX = event.x;
        this.startWidth = jQuery(this.start).parent().width();
        this.initResizableColumns();
    }
    initResizableColumns() {
        this.renderer.listenGlobal('body', 'mousemove', (event) => {
            if (this.pressed) {
                let width = this.startWidth + (event.x - this.startX);
                jQuery(this.start).parent().css({ 'min-width': width, 'max-   width': width });
                let index = jQuery(this.start).parent().index() + 1;
                jQuery('#' + this.pTableSetting.tableID + ' tr td:nth-child(' + index + ')').css({ 'min-width': width, 'max-width': width });
            }
        });
        this.renderer.listenGlobal('body', 'mouseup', (event) => {
            if (this.pressed) {
                this.pressed = false;
            }
        });
    }
    fnIndividualColumnFilterContext(columnDef, event) {
        this.filterCustomColumnName = columnDef.internalName;
        this.filterColumnTitle = columnDef.headerName;
        this.columnSearchValue = "";
        this.columnWiseMasterData = this.fnFindUniqueColumnWithCheckedFlag(this.pTableData, this.filterCustomColumnName) || [];
        this.customFilterUniqueArray = JSON.parse(JSON.stringify(this.columnWiseMasterData));
        let xPostion = 0;
        //to checked all
        this.filterItemsCheckedAll = true;
        console.log(event);
        //to set position of pop-up
        let totalScreenX = window.screen.width;
        console.log("total X: " + totalScreenX + " :pageY" + event.pageY + "event.target.offsetParent.offsetTop" + event.target.offsetParent.offsetTop + "target.offsetTop" + event.target.offsetTop + "event.view.scrollY:" + event.view.scrollY);
        if (event.pageX + 290 > totalScreenX) {
            xPostion = totalScreenX - 320;
        }
        else {
            xPostion = event.pageX;
        }
        let yPosition = event.pageY + 10;
        //let yPosition = '136';
        let ofset = { "top": yPosition, "left": xPostion };
        //let ofset = { "top": event.pageY - event.target.offsetParent.offsetTop - event.target.offsetTop - event.view.scrollY, "left": event.pageX - event.target.offsetParent.offsetLeft - event.target.offsetLeft - event.view.scrollX };
        //jQuery("#fitlerInfo").css(ofset).show();
        jQuery("#" + this.pTableSetting.tableID + "-fitlerInfo").css(ofset).show();
        //to set color of filter popup icon
        let checkFilterApplied = this.storedFilteredInfo.filter((rec) => { if (rec.columnName == this.filterCustomColumnName) {
            return true;
        }
        else {
            return false;
        } }) || [];
        this.popupFilterColor = 'black';
        if (checkFilterApplied.length > 0) {
            this.popupFilterColor = 'red';
        }
    }
    fnCustomFilterSelectAll(event) {
        if (event.target.checked) {
            this.customFilterUniqueArray.forEach((rec) => {
                rec.checked = true;
            });
        }
        else {
            this.customFilterUniqueArray.forEach((rec) => {
                rec.checked = false;
            });
        }
    }
    fnApplyCustomFilter() {
        this.pTableData = this.fnCustomFilterFromMasterArray(this.pTableData, this.filterCustomColumnName, this.customFilterUniqueArray.filter((rec) => rec.checked == true)) || [];
        jQuery("#" + this.pTableSetting["tableID"] + " #filter-icon-" + this.filterCustomColumnName).css('color', 'red');
        jQuery("#" + this.pTableSetting.tableID + "-fitlerInfo").hide();
        if (this.storedFilteredInfo.length > 0) {
            this.storedFilteredInfo = this.storedFilteredInfo.filter((rec) => { if (rec.columnName == this.filterCustomColumnName) {
                return false;
            }
            else {
                return true;
            } }) || [];
            this.storedFilteredInfo.push({ columnName: this.filterCustomColumnName, checkedItem: this.customFilterUniqueArray.filter((rec) => { if (rec.checked) {
                    return true;
                }
                else {
                    return false;
                } }) });
        }
        else {
            this.storedFilteredInfo.push({ columnName: this.filterCustomColumnName, checkedItem: this.customFilterUniqueArray.filter((rec) => { if (rec.checked) {
                    return true;
                }
                else {
                    return false;
                } }) });
        }
        this.setPage(1);
    }
    fnFilterPTableColumn(arg) {
        if (this.columnSearchValue.trim() != "") {
            this.customFilterUniqueArray = this.columnWiseMasterData.filter((rec) => { if (rec.data.toLowerCase().includes(this.columnSearchValue.toLowerCase())) {
                return true;
            }
            else {
                return false;
            } }) || [];
        }
        else {
            this.customFilterUniqueArray = JSON.parse(JSON.stringify(this.columnWiseMasterData));
        }
    }
    fnCustomFilterFromMasterArray(masterObject, findKey, data) {
        var o = {}, i, outer, l = masterObject.length, filteredData = [];
        for (outer = 0; outer < data.length; outer++) {
            let filterMasterData = masterObject.filter((record) => record['' + findKey + ''] == data[outer]["data"]) || [];
            filteredData = filteredData.concat(filterMasterData);
        }
        //console.log(filteredData)
        this.filterItemsCheckedAll = true;
        return filteredData;
    }
    fnApplyCustomCustomization() {
        return __awaiter(this, void 0, void 0, function* () {
            this.pTableSetting.tableColDef.forEach((rec) => {
                let columnLooping = this.pTableColumnCustomizationList.filter((record) => { if (record.internalName == rec.internalName) {
                    return true;
                }
                else {
                    return false;
                } }) || [];
                if (columnLooping.length > 0) {
                    rec.visible = columnLooping[0].visible;
                }
                else {
                    rec.visible = false;
                }
            });
            //assign again 
            if (this.storedFilteredInfo.length > 0) {
                this.pTableData = JSON.parse(JSON.stringify(this.pTableMasterData)) || [];
                this.storedFilteredInfo.forEach((rec) => {
                    jQuery("#" + this.pTableSetting["tableID"] + " #filter-icon-" + rec.columnName).css('color', 'white');
                });
                this.storedFilteredInfo = [];
                this.setPage(1);
            }
            //await this.fnShowPreviousFilteredState();   
            this.pTableColumnCustomizationList = JSON.parse(JSON.stringify(this.pTableSetting.tableColDef));
            this.pTableColumnReorder = JSON.parse(JSON.stringify(this.pTableSetting.tableColDef)) || [];
        });
    }
    fnPTableColumnCustomizationSearch(searchVal) {
        this.pTableColumnCustomizationList = this.pTableSetting.tableColDef.filter((record) => { if (record.headerName.toLowerCase().includes(searchVal.toLowerCase())) {
            return true;
        }
        else {
            return false;
        } }) || [];
    }
    fnCloseCustomFilter() {
        //jQuery("#fitlerInfo").hide();
        jQuery("#" + this.pTableSetting.tableID + "-fitlerInfo").hide();
    }
    selectTab(tab) {
        this.settingsTabs.forEach((rec) => {
            if (rec.tab == tab.tab) {
                rec.active = true;
            }
            else {
                rec.active = false;
            }
        });
        this.activeTabName = tab.tab;
    }
    fnChangeColumnOrder(colDef, index, status) {
        let old_index = index;
        let new_index = 0;
        debugger;
        //to check valid index
        if (index <= 0 && status == 'up') {
            return false;
        }
        else if (index >= this.pTableColumnReorder.length - 1 && status == 'down') {
            return false;
        }
        if (status == 'up') {
            new_index = index - 1;
        }
        else {
            new_index = index + 1;
        }
        if (new_index >= this.pTableColumnReorder.length) {
            var k = new_index - this.pTableColumnReorder.length;
            while ((k--) + 1) {
                this.pTableColumnReorder.push(undefined);
            }
        }
        this.pTableColumnReorder.splice(new_index, 0, this.pTableColumnReorder.splice(old_index, 1)[0]);
    }
    fnApplyReorderColumn() {
        this.pTableSetting.tableColDef = JSON.parse(JSON.stringify(this.pTableColumnReorder));
        this.pTableColumnCustomizationList = JSON.parse(JSON.stringify(this.pTableSetting.tableColDef)) || [];
    }
    onDrop(src, trg) {
        this.fnModeDragDropContent(this.pTableColumnReorder.map(x => x.internalName).indexOf(src.internalName), this.pTableColumnReorder.map(x => x.internalName).indexOf(trg.internalName));
        //myArray.map(x => x.hello).indexOf('stevie')
    }
    fnModeDragDropContent(src, trg) {
        src = parseInt(src);
        trg = parseInt(trg);
        if (trg >= this.pTableColumnReorder.length) {
            var k = trg - this.pTableColumnReorder.length;
            while ((k--) + 1) {
                this.pTableColumnReorder.push(undefined);
            }
        }
        this.pTableColumnReorder.splice(trg, 0, this.pTableColumnReorder.splice(src, 1)[0]);
        return this; // for testing purposes
    }
    fnFindUniqueColumnWithCheckedFlag(objectSet, findKey) {
        var o = {}, i, l = objectSet.length, r = [];
        for (i = 0; i < l; i++) {
            o[objectSet[i][findKey]] = objectSet[i][findKey];
        }
        ;
        for (i in o)
            r.push({ checked: true, data: o[i] });
        return r;
    }
    clearFilterFromFilterPopup() {
        return __awaiter(this, void 0, void 0, function* () {
            this.pTableData = JSON.parse(JSON.stringify(this.pTableMasterData));
            if (this.globalSearchValue.trim() != "") {
                yield this.fnFilterPTable(this.globalSearchValue, true);
            }
            //to remove filter from storedFilteredInfo variable
            if (this.storedFilteredInfo.length > 0) {
                this.storedFilteredInfo = this.storedFilteredInfo.filter((rec) => { if (rec.columnName == this.filterCustomColumnName) {
                    return false;
                }
                else {
                    return true;
                } }) || [];
            }
            if (this.storedFilteredInfo.length > 0) {
                this.storedFilteredInfo.forEach((rec) => {
                    this.pTableData = this.fnCustomFilterFromMasterArray(this.pTableData, rec.columnName, rec.checkedItem) || [];
                });
            }
            jQuery("#" + this.pTableSetting["tableID"] + " #filter-icon-" + this.filterCustomColumnName).css('color', 'white');
            jQuery("#" + this.pTableSetting.tableID + "-fitlerInfo").hide();
            this.setPage(1);
        });
    }
    fnShowPreviousFilteredState() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.storedFilteredInfo.length > 0) {
                this.storedFilteredInfo.forEach((rec) => {
                    this.pTableData = this.fnCustomFilterFromMasterArray(this.pTableData, rec.columnName, rec.checkedItem) || [];
                    jQuery("#" + this.pTableSetting["tableID"] + " #filter-icon-" + rec.columnName).css('color', 'red');
                });
            }
            // this.setPage(1);
        });
    }
    fnReflowTable() {
        if (this.pTableSetting.enabledCustomReflow) {
            if (this.customReflowActive) {
                this.customReflowActive = false;
                this.fnResetStyle("retrive");
            }
            else {
                this.customReflowActive = true;
                this.fnResetStyle("reset");
            }
            this.customReflowFn.emit(this.pTableSetting.tableID);
        }
        else {
            if (this.activeReflow) {
                jQuery("#" + this.pTableSetting.tableID + "-fitlerInfo").hide();
                this.activeReflow = false;
                this.fnResetStyle("retrive");
            }
            else {
                this.fnResetStyle("reset");
                this.activeReflow = true;
            }
        }
    }
    fnResetStyle(action) {
        if (action == "reset") {
            //remove previous style
            //if (this.pTableSetting.pTableStyle.overflowContentWidth != undefined && this.pTableSetting.pTableStyle.overflowContentWidth != null) {
            if (this.pTableSetting.pTableStyle != undefined && this.pTableSetting.pTableStyle != null) {
                this.tempStyle = [{ tableOverflow: this.pTableSetting.pTableStyle.tableOverflow || false, tableOverflowX: this.pTableSetting.pTableStyle.tableOverflowX || false, tableOverflowY: this.pTableSetting.pTableStyle.tableOverflowY || false, overflowContentWidth: this.pTableSetting.pTableStyle.overflowContentWidth || null, overflowContentHeight: this.pTableSetting.pTableStyle.overflowContentHeight || null }];
                this.pTableSetting.pTableStyle.overflowContentWidth = null;
                this.pTableSetting.pTableStyle.tableOverflowY = true;
                this.pTableSetting.pTableStyle.tableOverflow = false;
            }
        }
        else if (action == "retrive") {
            //to reset previous style
            if (this.tempStyle.length > 0) {
                this.pTableSetting.pTableStyle.overflowContentWidth = this.tempStyle[0].overflowContentWidth;
                this.pTableSetting.pTableStyle.overflowContentHeight = this.tempStyle[0].overflowContentHeight;
                this.pTableSetting.pTableStyle.tableOverflow = this.tempStyle[0].tableOverflow;
                this.pTableSetting.pTableStyle.tableOverflowX = this.tempStyle[0].tableOverflowX;
                this.pTableSetting.pTableStyle.tableOverflowY = this.tempStyle[0].tableOverflowY;
            }
        }
    }
};
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], PTableComponent.prototype, "pTableSetting", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], PTableComponent.prototype, "pTableMasterData", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], PTableComponent.prototype, "checkboxCallbackFn", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], PTableComponent.prototype, "callbackFnOnPageChange", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], PTableComponent.prototype, "radioButtonCallbackFn", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], PTableComponent.prototype, "cellClickCallbackFn", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], PTableComponent.prototype, "customReflowFn", void 0);
PTableComponent = __decorate([
    core_1.Component({
        selector: 'app-p-table',
        changeDetection: core_1.ChangeDetectionStrategy.Default,
        templateUrl: '/app/Shared/component/p-table/p-table.component.html',
        styleUrls: ['app/Shared/component/p-table/p-table.component.css'],
        providers: [p_table_pagger_1.PagerService],
    }),
    __metadata("design:paramtypes", [p_table_pagger_1.PagerService, core_1.KeyValueDiffers, core_1.Renderer])
], PTableComponent);
exports.PTableComponent = PTableComponent;
//# sourceMappingURL=p-table.component.js.map